package com.itmo.compstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
