package com.compshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CompshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
